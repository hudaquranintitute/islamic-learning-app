# Islamic Learning App — Android build starter

This is a real, minimal native Android project with a GitHub Actions workflow that builds a **debug APK**.

## Build from your phone using GitHub
1. Upload the *contents* of this ZIP into the root of your repository (keep folder paths).
2. Make sure `.github/workflows/build-apk.yml` is uploaded at exactly that path.
3. Open the repository's **Actions** tab and select **Build Android APK**.
4. Tap **Run workflow** if it has not started automatically.
5. When the run completes successfully, open the run, scroll to **Artifacts**, and download `Islamic-Learning-App-debug-APK`.
6. Extract the downloaded artifact ZIP and install `app-debug.apk`. Android may ask you to allow installs from your browser/files app.

## Important content limitations
This starter includes a working home screen, language toggle, a basic dua example, and a digital tasbeeh counter. Quran pages, Madani Qaida lessons/audio, Faizan-e-Namaz, and verified wazaif content are **not included yet**. Add only authorized, verified source material and audio before publishing. The generated APK is an unsigned debug build, suitable for testing—not a Play Store release.
