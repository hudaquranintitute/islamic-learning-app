package com.hudaquran.islamiclearning

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val navy = Color.rgb(9, 30, 58)
    private val gold = Color.rgb(212, 175, 98)
    private val cream = Color.rgb(250, 247, 238)
    private var count = 0
    private var urdu = false
    private lateinit var body: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun text(value: String, size: Float, color: Int = navy, bold: Boolean = false): TextView {
        return TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(12, 12, 12, 12)
        }
    }

    private fun button(label: String, action: () -> Unit): Button =
        Button(this).apply {
            text = label
            setTextColor(navy)
            setBackgroundColor(gold)
            textSize = 16f
            setOnClickListener { action() }
        }

    private fun shell(title: String) {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(cream)
        }
        root.addView(text(title, 24f, gold, true).apply {
            setBackgroundColor(navy); minimumHeight = 76
        })
        val scroll = ScrollView(this)
        body = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 18, 16, 24)
        }
        scroll.addView(body)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(button(if (urdu) "گھر" else "Home") { showHome() })
        setContentView(root)
    }

    private fun addHeading(s: String) { body.addView(text(s, 20f, navy, true)) }
    private fun addLine(s: String) { body.addView(text(s, 17f, navy)) }
    private fun addAction(s: String, action: () -> Unit) {
        body.addView(button(s, action), LinearLayout.LayoutParams(-1, -2).apply {
            setMargins(4, 7, 4, 7)
        })
    }

    private fun showHome() {
        shell(if (urdu) "اسلامک لرننگ ایپ" else "Islamic Learning App")
        addLine(if (urdu) "حُدیٰ قرآن انسٹی ٹیوٹ کی جانب سے" else "Represented by Huda Quran Institute")
        addLine("Learn • Practice • Grow")
        addAction(if (urdu) "قرآن مجید" else "Quran Majeed") { showInfo("Quran Majeed", "Add an authorized 16-line Quran text/PDF and recitation audio here.") }
        addAction(if (urdu) "مدنی قاعدہ" else "Madani Qaida") { showInfo("Madani Qaida", "Qaida lessons and audio content can be added here.") }
        addAction(if (urdu) "روزمرہ دعائیں" else "Daily Duas") { showDuas() }
        addAction(if (urdu) "فیضانِ نماز / نماز گائیڈ" else "Faizan-e-Namaz / Namaz Guide") { showInfo("Namaz Guide", "Prayer learning section. Verified Hanafi content should be added before publication.") }
        addAction(if (urdu) "ڈیجیٹل تسبیح" else "Digital Tasbeeh") { showTasbeeh() }
        addAction(if (urdu) "وظائف" else "Wazaif") { showInfo("Wazaif", "Add verified, referenced wazaif content here.") }
        addAction(if (urdu) "زبان تبدیل کریں: اردو / English" else "Change Language: English / اردو") {
            urdu = !urdu; showHome()
        }
    }

    private fun showTasbeeh() {
        shell("Digital Tasbeeh")
        val counter = text(count.toString(), 42f, navy, true)
        body.addView(counter)
        addAction("+  Count") { count++; counter.text = count.toString() }
        addAction("Reset") { count = 0; counter.text = "0" }
    }

    private fun showDuas() {
        shell("Daily Duas / روزمرہ دعائیں")
        addHeading("Dua before increasing knowledge")
        addLine("رَبِّ زِدْنِي عِلْمًا")
        addLine("Rabbi zidni ilma")
        addLine("اے میرے رب! میرے علم میں اضافہ فرما۔")
        addHeading("More daily duas")
        addLine("A verified collection of daily duas can be added in this section.")
    }

    private fun showInfo(title: String, message: String) {
        shell(title); addLine(message)
    }
}
